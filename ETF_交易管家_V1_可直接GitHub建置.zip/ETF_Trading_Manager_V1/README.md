# ETF交易管家 V1

Android APK 測試版。

功能：
- 總覽
- 持股清單
- 買進／賣出交易紀錄
- 股息紀錄
- 本機儲存
- 手續費設定：2.8 折

## 在 GitHub 建置 APK

本專案已附 `.github/workflows/build-apk.yml`。
上傳專案內容到 GitHub 的 `main` 分支後，GitHub Actions 會自動建置 Debug APK。
完成後到 Actions → Build APK → 最新成功的執行 → Artifacts 下載 `ETFTradingManager-debug`。
